# Growfinix AI Internship Tasks — Professional UI Edition

Three completed Month 1 tasks with polished browser interfaces and API backends:

- Task 2 — AI-Powered Data Extraction
- Task 3 — Semantic Sentiment & Urgency Analyzer
- Task 5 — AI Chat Interface

## What changed
The projects are designed as actual demo applications rather than plain API-only demos.
Tasks 2 and 3 include browser dashboards with sample inputs, clear result cards, JSON/analysis output,
loading states and responsive layouts. Task 5 is a polished ChatGPT-style interface.

## Run
See the README inside each task folder for exact commands.
