# Task 2 — AI-Powered Data Extraction

A polished web application that converts messy tour-enquiry text into structured JSON.

### Extracted fields
- Customer name
- Start date
- End date
- Destination

### Stack
Python · FastAPI · OpenAI API · HTML/CSS/JavaScript

### Run
```powershell
cd task-2-data-extraction
python -m pip install -r requirements.txt
copy .env.example .env
python -m uvicorn app:app --reload
```

Open `http://127.0.0.1:8000`.

If `OPENAI_API_KEY` is empty, the app uses a deterministic demo extractor so the UI can still be demonstrated.
For a live LLM demonstration, add the key to `.env` and restart the server.
