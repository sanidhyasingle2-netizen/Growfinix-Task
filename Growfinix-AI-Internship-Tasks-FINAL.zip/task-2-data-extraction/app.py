import json, os, re
from datetime import datetime
from typing import Optional
from urllib.request import Request, urlopen

from dotenv import load_dotenv
from fastapi import FastAPI
from fastapi.responses import HTMLResponse
from pydantic import BaseModel, Field

load_dotenv()
app = FastAPI(title="Growfinix Task 2")

class ExtractionRequest(BaseModel):
    text: str = Field(min_length=3)

class TourInquiry(BaseModel):
    customer_name: Optional[str] = None
    start_date: Optional[str] = None
    end_date: Optional[str] = None
    destination: Optional[str] = None

def demo_extract(text):
    result = {"customer_name": None, "start_date": None, "end_date": None, "destination": None}
    m = re.search(r"(?:this is|i am|my name is)\s+([A-Z][A-Za-z]+(?:\s+[A-Z][A-Za-z]+){1,3})", text, re.I)
    if m: result["customer_name"] = m.group(1).strip()
    dates = re.findall(r"\b(\d{1,2}\s+(?:January|February|March|April|May|June|July|August|September|October|November|December)\s+\d{4})\b", text, re.I)
    parsed = []
    for d in dates[:2]:
        try: parsed.append(datetime.strptime(d, "%d %B %Y").date().isoformat())
        except ValueError: pass
    if parsed: result["start_date"] = parsed[0]
    if len(parsed) > 1: result["end_date"] = parsed[1]
    for city in ["Goa","Mumbai","Delhi","Jaipur","Udaipur","Manali","Kerala","Kashmir","Dubai","Bali","Singapore","London","Paris"]:
        if re.search(rf"\b{re.escape(city)}\b", text, re.I):
            result["destination"] = city; break
    return result

def openai_extract(text):
    key = os.getenv("OPENAI_API_KEY")
    if not key: return demo_extract(text)
    payload = {
        "model": os.getenv("OPENAI_MODEL","gpt-4o-mini"),
        "temperature": 0,
        "messages": [
            {"role":"system","content":"Extract a tour enquiry. Return ONLY JSON with exactly customer_name, start_date, end_date, destination. Dates must be YYYY-MM-DD. Missing fields must be null. Never invent information."},
            {"role":"user","content":text}
        ],
        "response_format":{"type":"json_object"}
    }
    req = Request("https://api.openai.com/v1/chat/completions",
        data=json.dumps(payload).encode(),
        headers={"Authorization":f"Bearer {key}","Content-Type":"application/json"})
    with urlopen(req, timeout=60) as r: data=json.loads(r.read())
    return json.loads(data["choices"][0]["message"]["content"])

@app.get("/", response_class=HTMLResponse)
def home():
    return HTML

@app.post("/extract", response_model=TourInquiry)
def extract(req: ExtractionRequest):
    return openai_extract(req.text)

HTML = r"""<!doctype html>
<html lang="en"><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Growfinix • Smart Data Extractor</title>
<style>
*{box-sizing:border-box}body{margin:0;font-family:Inter,system-ui,Segoe UI,sans-serif;background:#f5f7fb;color:#172033}
.top{height:72px;background:#fff;border-bottom:1px solid #e6e9ef;display:flex;align-items:center;padding:0 7%;justify-content:space-between}
.logo{font-weight:800;font-size:20px;letter-spacing:-.4px}.logo b{color:#6d5dfc}.tag{font-size:12px;color:#6b7280;border:1px solid #e5e7eb;padding:7px 11px;border-radius:99px}
.wrap{max-width:1180px;margin:48px auto;padding:0 22px}.hero h1{font-size:44px;letter-spacing:-1.8px;margin:0 0 10px}.hero p{color:#667085;max-width:700px;line-height:1.7;margin:0 0 34px}
.grid{display:grid;grid-template-columns:1.08fr .92fr;gap:22px}.card{background:#fff;border:1px solid #e7eaf0;border-radius:20px;box-shadow:0 10px 35px #1822300b;padding:24px}.label{font-size:13px;font-weight:700;margin-bottom:11px}.hint{font-size:12px;color:#8a93a3;margin:0 0 12px}
textarea{width:100%;height:235px;border:1px solid #dce1e9;border-radius:14px;padding:16px;font:14px/1.6 inherit;resize:vertical;outline:none}textarea:focus{border-color:#6d5dfc;box-shadow:0 0 0 3px #6d5dfc18}
.actions{display:flex;gap:10px;margin-top:14px}button{border:0;border-radius:11px;padding:11px 17px;font-weight:700;cursor:pointer}.primary{background:#171c2c;color:#fff}.secondary{background:#eef0f5;color:#394150}.primary:disabled{opacity:.55}
.status{margin-top:13px;font-size:12px;color:#778094;min-height:18px}.result-head{display:flex;justify-content:space-between;align-items:center}.pill{font-size:11px;background:#ecfdf3;color:#087443;padding:6px 9px;border-radius:99px}
.fields{display:grid;grid-template-columns:1fr 1fr;gap:12px;margin-top:18px}.field{background:#f8f9fc;border:1px solid #edf0f4;border-radius:13px;padding:15px}.field small{display:block;color:#8992a3;font-size:11px;margin-bottom:7px}.field strong{font-size:14px;word-break:break-word}
pre{background:#111827;color:#dbe4f0;border-radius:14px;padding:17px;overflow:auto;font-size:12px;line-height:1.6;margin-top:18px}
.footer{text-align:center;color:#9aa2b1;font-size:11px;margin:30px}
@media(max-width:850px){.grid{grid-template-columns:1fr}.hero h1{font-size:34px}.fields{grid-template-columns:1fr}}
</style></head><body>
<header class="top"><div class="logo">Growfinix <b>AI</b></div><div class="tag">Internship · Task 2</div></header>
<main class="wrap"><section class="hero"><h1>Smart Data Extractor</h1><p>Turn unstructured customer enquiries into clean, structured information using AI.</p></section>
<section class="grid"><div class="card"><div class="label">Customer enquiry</div><p class="hint">Paste a messy email, message or tour enquiry below.</p>
<textarea id="input">Hi, this is Rahul Sharma. I would like to visit Goa from 12 October 2026 to 16 October 2026. Please send me a quotation.</textarea>
<div class="actions"><button class="primary" id="run" onclick="extract()">Extract information</button><button class="secondary" onclick="sample()">Use sample</button></div><div class="status" id="status"></div></div>
<div class="card"><div class="result-head"><div class="label">Structured result</div><div class="pill">JSON ready</div></div>
<div class="fields"><div class="field"><small>CUSTOMER NAME</small><strong id="name">—</strong></div><div class="field"><small>DESTINATION</small><strong id="dest">—</strong></div><div class="field"><small>START DATE</small><strong id="start">—</strong></div><div class="field"><small>END DATE</small><strong id="end">—</strong></div></div><pre id="json">{}</pre></div></section>
<div class="footer">Growfinix AI Internship · Advanced data extraction demo</div></main>
<script>
function sample(){document.getElementById('input').value='Hi, this is Rahul Sharma. I would like to visit Goa from 12 October 2026 to 16 October 2026. Please send me a quotation.'}
async function extract(){let text=document.getElementById('input').value.trim(),btn=document.getElementById('run'),s=document.getElementById('status');if(!text)return;
btn.disabled=true;s.textContent='Extracting information…';try{let r=await fetch('/extract',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({text})});let d=await r.json();if(!r.ok)throw Error(d.detail||'Request failed');
document.getElementById('name').textContent=d.customer_name||'Not found';document.getElementById('dest').textContent=d.destination||'Not found';document.getElementById('start').textContent=d.start_date||'Not found';document.getElementById('end').textContent=d.end_date||'Not found';document.getElementById('json').textContent=JSON.stringify(d,null,2);s.textContent='Extraction completed successfully.'}catch(e){s.textContent='Error: '+e.message}finally{btn.disabled=false}}
extract();
</script></body></html>"""
