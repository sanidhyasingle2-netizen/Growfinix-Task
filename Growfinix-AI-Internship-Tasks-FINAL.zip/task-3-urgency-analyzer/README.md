# Task 3 — Semantic Sentiment & Urgency Analyzer

A browser dashboard for customer-support ticket triage.

### Output
- Sentiment: Positive / Negative / Neutral
- Urgency: High / Medium / Low
- Core complaint or praise
- Recommended priority

### Run
```powershell
cd task-3-urgency-analyzer
python -m pip install -r requirements.txt
copy .env.example .env
python -m uvicorn app:app --reload --port 8001
```

Open `http://127.0.0.1:8001`.

With no Hugging Face token, the app uses a local deterministic fallback for demonstrations.
