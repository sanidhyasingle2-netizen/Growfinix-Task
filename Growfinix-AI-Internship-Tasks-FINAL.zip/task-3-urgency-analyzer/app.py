import json, os, re
from urllib.request import Request, urlopen
from dotenv import load_dotenv
from fastapi import FastAPI
from fastapi.responses import HTMLResponse
from pydantic import BaseModel, Field

load_dotenv()
app=FastAPI(title="Growfinix Task 3")

class TicketRequest(BaseModel):
    text:str=Field(min_length=3)

HIGH=["urgent","immediately","asap","emergency","tonight","blocked","fraud","stolen","failed","cannot","can't","not working","deducted"]
MEDIUM=["delay","late","problem","issue","error","refund","complaint","help"]
POS=["thank","great","excellent","good","happy","satisfied","love"]
NEG=["bad","terrible","angry","disappointed","failed","error","problem","complaint"]

def local(text):
    t=text.lower(); h=sum(x in t for x in HIGH); m=sum(x in t for x in MEDIUM)
    pos=sum(x in t for x in POS); neg=sum(x in t for x in NEG)
    if h>=2 or any(x in t for x in ["fraud","stolen","emergency"]): urgency,priority="High",1
    elif h>=1 or m>=2: urgency,priority="Medium",2
    else: urgency,priority="Low",3
    sentiment="Positive" if pos>neg else "Negative" if neg>pos else "Neutral"
    sentences=re.split(r"(?<=[.!?])\s+",text.strip())
    core=min(sentences,key=len) if sentences else text
    return {"sentiment":sentiment,"urgency":urgency,"core_issue":core[:240],"recommended_priority":priority}

def hf(text):
    token=os.getenv("HF_API_TOKEN")
    if not token:return local(text)
    model=os.getenv("HF_SENTIMENT_MODEL","cardiffnlp/twitter-roberta-base-sentiment-latest")
    try:
        req=Request(f"https://api-inference.huggingface.co/models/{model}",
            data=json.dumps({"inputs":text}).encode(),
            headers={"Authorization":f"Bearer {token}","Content-Type":"application/json"})
        with urlopen(req,timeout=30) as r:data=json.loads(r.read())
        labels=data[0] if isinstance(data,list) else data
        best=max(labels,key=lambda x:x["score"]); lab=best["label"].lower()
        out=local(text);out["sentiment"]="Positive" if "positive" in lab else "Negative" if "negative" in lab else "Neutral"
        return out
    except Exception:return local(text)

@app.get("/",response_class=HTMLResponse)
def home():return HTML

@app.post("/analyze")
def analyze(req:TicketRequest):return hf(req.text)

HTML=r"""<!doctype html><html><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Growfinix • Support Intelligence</title>
<style>
*{box-sizing:border-box}body{margin:0;font-family:Inter,system-ui,Segoe UI,sans-serif;background:#f5f7fb;color:#172033}.top{height:72px;background:#fff;border-bottom:1px solid #e6e9ef;display:flex;align-items:center;padding:0 7%;justify-content:space-between}.logo{font-weight:800;font-size:20px}.logo b{color:#6d5dfc}.tag{font-size:12px;color:#6b7280;border:1px solid #e5e7eb;padding:7px 11px;border-radius:99px}.wrap{max-width:1180px;margin:48px auto;padding:0 22px}.hero h1{font-size:44px;letter-spacing:-1.8px;margin:0 0 10px}.hero p{color:#667085;line-height:1.7;margin-bottom:34px}.grid{display:grid;grid-template-columns:1fr 1fr;gap:22px}.card{background:#fff;border:1px solid #e7eaf0;border-radius:20px;padding:24px;box-shadow:0 10px 35px #1822300b}.label{font-size:13px;font-weight:700;margin-bottom:11px}.hint{font-size:12px;color:#8a93a3}textarea{width:100%;height:235px;border:1px solid #dce1e9;border-radius:14px;padding:16px;font:14px/1.6 inherit;resize:vertical;outline:0}textarea:focus{border-color:#6d5dfc}.actions{display:flex;gap:10px;margin-top:14px}button{border:0;border-radius:11px;padding:11px 17px;font-weight:700;cursor:pointer}.primary{background:#171c2c;color:#fff}.secondary{background:#eef0f5;color:#394150}.primary:disabled{opacity:.55}.status{margin-top:13px;font-size:12px;color:#778094;min-height:18px}.score{display:flex;gap:12px;margin:18px 0}.metric{flex:1;border:1px solid #edf0f4;border-radius:14px;padding:16px;background:#f8f9fc}.metric small{display:block;color:#8992a3;font-size:10px;margin-bottom:7px}.metric strong{font-size:18px}.high{color:#b42318}.medium{color:#b54708}.low{color:#087443}.issue{border:1px solid #edf0f4;border-radius:14px;padding:16px;background:#fafbfc;line-height:1.6;font-size:14px}.priority{margin-top:12px;font-size:12px;color:#667085}.footer{text-align:center;color:#9aa2b1;font-size:11px;margin:30px}@media(max-width:850px){.grid{grid-template-columns:1fr}.hero h1{font-size:34px}.score{flex-direction:column}}
</style></head><body><header class="top"><div class="logo">Growfinix <b>AI</b></div><div class="tag">Internship · Task 3</div></header>
<main class="wrap"><section class="hero"><h1>Support Intelligence</h1><p>Understand customer sentiment and urgency so support teams can prioritize the right tickets first.</p></section>
<section class="grid"><div class="card"><div class="label">Support ticket</div><p class="hint">Paste customer feedback or a support complaint.</p>
<textarea id="input">My payment has been deducted but the ticket is still not confirmed. I need this fixed urgently because my train leaves tonight.</textarea>
<div class="actions"><button class="primary" id="run" onclick="analyze()">Analyze ticket</button><button class="secondary" onclick="sample()">Use sample</button></div><div class="status" id="status"></div></div>
<div class="card"><div class="label">AI triage result</div><div class="score"><div class="metric"><small>SENTIMENT</small><strong id="sent">—</strong></div><div class="metric"><small>URGENCY</small><strong id="urg">—</strong></div></div><div class="label">Core issue</div><div class="issue" id="issue">Waiting for analysis…</div><div class="priority" id="priority"></div></div></section><div class="footer">Growfinix AI Internship · Semantic sentiment & urgency analysis</div></main>
<script>
function sample(){document.getElementById('input').value="My payment has been deducted but the ticket is still not confirmed. I need this fixed urgently because my train leaves tonight."}
async function analyze(){let text=document.getElementById('input').value.trim(),btn=document.getElementById('run'),s=document.getElementById('status');if(!text)return;btn.disabled=true;s.textContent='Analyzing ticket…';try{let r=await fetch('/analyze',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({text})});let d=await r.json();if(!r.ok)throw Error(d.detail||'Request failed');let u=document.getElementById('urg');u.textContent=d.urgency;u.className=d.urgency.toLowerCase();document.getElementById('sent').textContent=d.sentiment;document.getElementById('issue').textContent=d.core_issue;document.getElementById('priority').textContent='Recommended support priority: '+d.recommended_priority+' / 3';s.textContent='Analysis completed successfully.'}catch(e){s.textContent='Error: '+e.message}finally{btn.disabled=false}}analyze();
</script></body></html>"""
