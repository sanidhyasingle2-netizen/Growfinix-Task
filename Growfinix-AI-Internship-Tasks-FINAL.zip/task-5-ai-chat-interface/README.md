# Task 5 — Frontend AI Chat Interface

A polished responsive ChatGPT-style interface.

### Features
- React + Vite frontend
- FastAPI backend
- Markdown rendering
- Conversation history
- Loading state
- New conversation / clear chat
- Responsive mobile layout
- OpenAI API integration with demo fallback

### Run backend
```powershell
cd task-5-ai-chat-interface\backend
python -m pip install -r requirements.txt
copy .env.example .env
python -m uvicorn app:app --reload --port 8002
```

### Run frontend
In a second terminal:
```powershell
cd task-5-ai-chat-interface\frontend
npm install
npm run dev
```
Open the URL shown by Vite, usually `http://localhost:5173`.
