import json, os
from urllib.request import Request, urlopen
from dotenv import load_dotenv
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel

load_dotenv()
app=FastAPI(title="Growfinix Task 5")
app.add_middleware(CORSMiddleware,allow_origins=["*"],allow_credentials=False,allow_methods=["*"],allow_headers=["*"])

class Message(BaseModel):
    role:str
    content:str
class ChatRequest(BaseModel):
    messages:list[Message]

def demo(text):
    if "inflation" in text.lower():
        return "### Inflation\n\nInflation means the general prices of goods and services rise over time.\n\n**Example:** If a basket of groceries costs ₹1,000 today and ₹1,060 next year, it became 6% more expensive.\n\n**Simple idea:** your money buys a little less than before."
    return "I am running in **demo mode** because no OpenAI API key is configured. Add `OPENAI_API_KEY` to the backend `.env` to enable live AI responses."

def ai(messages):
    key=os.getenv("OPENAI_API_KEY")
    if not key:return demo(messages[-1]["content"])
    payload={"model":os.getenv("OPENAI_MODEL","gpt-4o-mini"),"temperature":.7,
             "messages":[{"role":"system","content":"You are a helpful AI assistant. Give clear, useful answers in Markdown."},*messages]}
    req=Request("https://api.openai.com/v1/chat/completions",data=json.dumps(payload).encode(),
                headers={"Authorization":f"Bearer {key}","Content-Type":"application/json"})
    with urlopen(req,timeout=60) as r:data=json.loads(r.read())
    return data["choices"][0]["message"]["content"]

@app.get("/")
def home():return {"project":"Growfinix Task 5","status":"running"}
@app.post("/chat")
def chat(req:ChatRequest):return {"reply":ai([m.model_dump() for m in req.messages])}
