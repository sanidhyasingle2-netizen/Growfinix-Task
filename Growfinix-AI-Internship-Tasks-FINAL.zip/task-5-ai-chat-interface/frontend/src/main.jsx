import React,{useState} from "react";
import {createRoot} from "react-dom/client";
import ReactMarkdown from "react-markdown";
import "./styles.css";

const starter={role:"assistant",content:"## Welcome to Growfinix AI 👋\n\nI'm ready to help. Ask a question and I'll respond with clear, structured answers."};

function App(){
 const [messages,setMessages]=useState([starter]),[input,setInput]=useState(""),[loading,setLoading]=useState(false);
 async function send(e){e?.preventDefault();let text=input.trim();if(!text||loading)return;let next=[...messages,{role:"user",content:text}];setMessages(next);setInput("");setLoading(true);
 try{let r=await fetch("http://127.0.0.1:8002/chat",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({messages:next})});let d=await r.json();setMessages([...next,{role:"assistant",content:d.reply}])}
 catch{setMessages([...next,{role:"assistant",content:"⚠️ I couldn't reach the backend. Please start the FastAPI server on port 8002."}])}finally{setLoading(false)}}
 function reset(){setMessages([starter]);setInput("")}
 return <div className="app">
  <aside><div className="brand"><span>✦</span> Growfinix AI</div><button className="new" onClick={reset}>＋ New conversation</button><div className="sideTitle">PROJECT</div><div className="project">AI Internship<br/><b>Task 5 · Chat Interface</b></div><div className="sideFoot">Built with React + FastAPI</div></aside>
  <main><header><div><b>AI Assistant</b><small><i/> Online</small></div><button className="clear" onClick={reset}>Clear chat</button></header>
  <section className="chat">{messages.map((m,i)=><div className={"row "+m.role} key={i}><div className="avatar">{m.role==="assistant"?"✦":"U"}</div><div className="bubble"><ReactMarkdown>{m.content}</ReactMarkdown></div></div>)}{loading&&<div className="row assistant"><div className="avatar">✦</div><div className="bubble typing">Thinking <span>•</span><span>•</span><span>•</span></div></div>}</section>
  <form className="composer" onSubmit={send}><input value={input} onChange={e=>setInput(e.target.value)} placeholder="Message Growfinix AI..." disabled={loading}/><button disabled={loading||!input.trim()}>➤</button></form>
  <div className="bottom">Growfinix AI Internship · Task 5</div></main></div>
}
createRoot(document.getElementById("root")).render(<App/>);
